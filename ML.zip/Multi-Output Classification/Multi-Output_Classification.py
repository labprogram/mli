# Implementation of Multi-Output Classification

import pandas as pd
import numpy as np
import neattext.functions as nfx
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.multioutput import MultiOutputClassifier
from sklearn.pipeline import Pipeline

df = pd.read_csv('C:/Users/ADMIN/Downloads/netflix_titles.csv')

df.dropna(subset=['title', 'type', 'rating'], inplace=True)  
df['title'] = df['title'].apply(lambda x: nfx.remove_stopwords(str(x).lower())) 

Xfeatures = df['title']
ylabels = df[['type', 'rating']]

x_train, x_test, y_train, y_test = train_test_split(Xfeatures, ylabels, test_size=0.3, random_state=7)

pipe_lr = Pipeline(steps=[('cv', CountVectorizer()), ('lr_multi', MultiOutputClassifier(LogisticRegression()))])
pipe_lr.fit(x_train, y_train)

print("Model Accuracy:", pipe_lr.score(x_test, y_test))

pred1 = x_test.iloc[0]
print("Sample Input:", pred1)
print("Actual Output:", y_test.iloc[0])
print("Predicted Output:", pipe_lr.predict([pred1]))