# Generate a multi-output data with a make_multilabel_classification function. 
# The target dataset contains 10 features (x), 2 classes (y), and 5000 samples, and implement the above algorithm.

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

train=pd.read_csv('C:/Users/ADMIN/Downloads/fashion-mnist_train.csv')
test=pd.read_csv('C:/Users/ADMIN/Downloads/fashion-mnist_test.csv')

train.columns = train.columns.str.strip()
test.columns = test.columns.str.strip()

if 'Label' not in train.columns or 'Label' not in test.columns:
    print("Error: 'label' column not found in dataset. Check column names:", train.columns)
    exit()

x_train=train.drop(columns=['label'])
y_train=train['label']
x_test=test.drop(columns=['label'])
y_test=test['label']

x_train_list=x_train.values.tolist()

plt.imshow(np.array(x_train_list[0]).reshape(28,28),cmap='gray')
plt.show()