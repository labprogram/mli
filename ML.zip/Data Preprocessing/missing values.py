# Implement a program to clean a dataset of missing values

import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer

def gen():
    df = pd.DataFrame({'Passenger ID': [12, 34, 5, 6],
                       'Age': [56, 34, 54, np.nan]})  
    print(df)
    return df

def clean(df):
    imputer = SimpleImputer(strategy='mean')
    df['Age'] = imputer.fit_transform(df[['Age']])
    print(df)
    return df

df = gen()
df = clean(df)