#Implement a program to calculate the coefficient of determination for a linear regression model.

import numpy as np
import matplotlib.pyplot as plt
def r_squared(y_true, y_pred):
    return 1 - np.sum((y_true - y_pred) ** 2) / np.sum((y_true - np.mean(y_true)) ** 2)
x = np.array([1, 2, 3, 4, 5])
y_true = np.array([3, 5, 7, 9, 11])
y_pred = np.array([2, 4, 6, 8, 10])
m, b = np.polyfit(x, y_true, 1)
y_pred = m * x + b
print(r_squared(y_true, y_pred))
plt.scatter(x, y_true, color='blue')   
plt.plot(x, y_pred, color='red')
plt.title('R-Squared Value')
plt.xlabel('X')
plt.ylabel('Y')
plt.show()